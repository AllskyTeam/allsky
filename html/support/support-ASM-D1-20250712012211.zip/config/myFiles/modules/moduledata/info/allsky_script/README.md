# AllSky Script Module

|   |   |
| ------------ | ------------ |
| **Status**  | Experimental  |
| **Level**  | Experienced  |
| **Runs In**  | Day time, Night time, endofnight, day/night transition, night/day transition  |


This module allows a custom script to be run. The script has the following options available

|  Setting | Description  |
| ------------ | ------------ |
| File Location | The location of the script to execute. Please see the notes below  |

**NOTES:** The script to be executed can be written in any language but MUST be an executable