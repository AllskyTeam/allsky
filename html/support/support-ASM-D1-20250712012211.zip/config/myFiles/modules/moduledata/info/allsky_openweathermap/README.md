# AllSky Weather Module

|   |   |
| ------------ | ------------ |
| **Status**  | Stable  |
| **Level**  | Experienced  |
| **Runs In**  | periodic  |


This module allows data to be retreived from the Open Wether Map API

|  Setting | Description  |
| ------------ | ------------ |
| API Key | Your Open Weather Map API key  |

**NOTES:** Please visit https://openweathermap.org/ to register for an API key

