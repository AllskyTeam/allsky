# AllSky Weather Module

|   |   |
| ------------ | ------------ |
| **Status**  | Stable  |
| **Level**  | Experienced  |
| **Runs In**  | periodic  |


This module allows data to be retreived from the Weather Underground API
based on the openweathermap module by Alex Greenland

|  Setting | Description  |
| ------------ | ------------ |
| API Key | Your Weather Underground API key  |
| Station ID | Your Weather Underground Station |

**NOTES:** Please visit https://www.wunderground.com/ to register for an API key

