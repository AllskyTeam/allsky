# AllSky INA3221 Module

|   |   |
| ------------ | ------------ |
| **Status**  | Experimental  |
| **Level**  | Experienced  |
| **Runs In**  | Periodic |

A simple module to read 1 to 3 channels from an INA3221 voltage and current sensor.

These modules can be useful for monitoring the current being fed to a dew heater to determine if its actually working or not
